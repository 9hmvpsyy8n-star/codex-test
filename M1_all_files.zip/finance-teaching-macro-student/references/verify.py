from pathlib import Path
import json, hashlib
from playwright.sync_api import sync_playwright
root=Path('/workspace/m1');out=root/'output'
for name in ['summary.csv','selected_events.csv','rebuilt_events.csv','audit.json','report.html']:
 assert (out/name).read_bytes()==(root/'repeat'/name).read_bytes(), name
requests=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 context=browser.new_context(offline=True,viewport={'width':1440,'height':1000})
 page=context.new_page();page.on('request',lambda req: requests.append(req.url));errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((out/'report.html').read_text(encoding='utf-8'),wait_until='load')
 assert page.locator('svg').count()==1
 assert page.locator('svg circle').count()==3
 assert page.locator('table').count()==2
 assert page.locator('h1').inner_text()=='流动性政策公告附近的五日累计异常收益'
 assert '77.403' in page.locator('table').first.inner_text()
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
 page.screenshot(path=str(root/'report_preview.png'),full_page=True)
 page.set_viewport_size({'width':390,'height':844})
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
 assert not errors
 assert not any(x.startswith(('http://','https://')) for x in requests)
 browser.close()
verification={'repeat_identical':['summary.csv','selected_events.csv','rebuilt_events.csv','audit.json','report.html'],'browser':'Chromium; offline=True; HTML read from disk and rendered with set_content; file:// navigation blocked by browser administrator policy','chart_points':3,'tables':2,'remote_requests':0,'javascript_errors':errors,'desktop_and_mobile_page_overflow':False}
(root/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2));print(json.dumps(verification,ensure_ascii=False))
