# M1运行与交付记录

本包为本次实际执行的技能和独立编写的复算脚本，不是论文作者代码，也未下载到教师脚本。仅支持liquidity与CAR[-1,3]，其他任务须另行扩展。

在技能根目录运行：

```sh
python3 scripts/analyze.py --policy liquidity --y car5 --author '你的姓名' --out outputs/M1 --narrative references/narrative_M1.json
```

Python依赖见requirements.txt；生成report.html、summary.csv、selected_events.csv、audit.json、rebuilt_events.csv和rebuild_comparison.csv。无联网取数依赖。课程冻结原始输入保留于data，来源说明一并保留；未扩大数据用途或声称来自本人下载。

本次核验：522行独立OLS重建，最大差4.192202140984591e-13 bp。三期事件数18/7/12，均值−0.589053/77.403481/29.776148 bp。same_date_rows仅为上游元数据，当前日期无重复。事件日期2020-12-15的描述存在不一致，未自行改动数据。报告用参考样本结构，但数值自行运算。

重复运行的统计CSV和HTML逐字节一致。Chromium离线读取HTML内容渲染，3个图点和2张表存在，零外部网络请求，桌面和手机宽度无整页溢出；file://导航被管理员策略阻止，未声称直接双击打开已测。verify.py为本次过程证据，其环境路径需按本地目录调整，不是生成报告的依赖。

用户未提供姓名，尚未提供本人核验记录；提交前请补填姓名、用计算器复核报告中的7项均值输入、打开CSV核对3个指定事件，并如实修改AI使用说明。报告可由上面命令重新生成。课堂平台上传入口在当前工具中不可用，未上传报告或ZIP。

无适用于本工作目录的AGENTS.md文件，因此包内没有虚构或新建AGENTS.md。SKILL.md及scripts/analyze.py为实际使用版本。未包括密钥、账户配置、整个运行环境或无关附件。
