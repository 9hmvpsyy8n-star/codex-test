#!/usr/bin/env python3
"""Independent classroom reproduction; not the paper author's or teacher's code."""
from pathlib import Path
import argparse, hashlib, json, html, re
import numpy as np
import pandas as pd
from scipy import stats
P=argparse.ArgumentParser()
P.add_argument('--policy',choices=['liquidity'],default='liquidity')
P.add_argument('--y',choices=['car5'],default='car5')
P.add_argument('--author',default='未署名（提交前填写）')
P.add_argument('--out',required=True)
P.add_argument('--narrative')
a=P.parse_args(); base=Path(__file__).resolve().parents[1];data=base/'data';out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
category={'liquidity':'Liquidity Decisions','interest':'Interest Rate Decisions','easing':'Monetary Easing Decisions'}[a.policy]
window={'car5':'[-1,3]','ar0':'[0,0]'}[a.y]
labels={'pre':'疫情前','during':'论文定义的疫情期间','post':'后续时期'}
prices=pd.read_csv(data/'prices_daily.csv');pol=pd.read_csv(data/'policy_events.csv');ev=pd.read_csv(data/'market_events.csv');paper=pd.read_csv(data/'paper_table3_full.csv')
manifest=json.loads((data/'manifest.json').read_text())
for row in pol.itertuples():
 expected='pre' if '2019-01-01'<=row.date<='2019-12-30' else 'during' if '2019-12-31'<=row.date<='2020-04-28' else 'post' if '2020-04-29'<=row.date<='2021-04-30' else None
 assert row.period==expected, 'period boundary mismatch'

hashval=hashlib.sha256((data/'market_events.csv').read_bytes()).hexdigest()
assert hashval==manifest['market_events_sha256']
assert len(ev)==manifest['rows'] and (ev.series_n==30).all()
assert not prices.duplicated(['code','date']).any()
assert not pol.duplicated(['category','date']).any()
assert not ev.duplicated(['category','event_date','window']).any()
assert prices.notna().all().all()
assert np.allclose(prices.return_pct/100,prices.r,atol=1e-12,rtol=0)
wide=prices.pivot(index='date',columns='code',values='return_pct').sort_index()/100
assert wide.shape[1]==31 and not wide.isna().any().any()
calendar=wide.index.to_numpy();market=wide['000001.SH'].to_numpy();industries=wide.drop(columns='000001.SH').to_numpy()
rebuilt=[];effective=[];mappings=[]
for row in pol.itertuples():
 t=int(np.searchsorted(calendar,row.date));assert t<len(calendar)
 assert t>=250
 x=np.column_stack([np.ones(231),market[t-250:t-19]])
 y=industries[t-250:t-19]
 assert len(x)==231 and np.isfinite(y).all() and np.linalg.matrix_rank(x)==2
 beta=np.linalg.lstsq(x,y,rcond=None)[0]
 effective.append(len(x));mappings.append((row.category,row.date,calendar[t]))
 for w in ev.window.unique():
  lo,hi=map(int,re.findall(r'-?\d+',w));assert t+lo>=0 and t+hi<len(calendar)
  xe=np.column_stack([np.ones(hi-lo+1),market[t+lo:t+hi+1]])
  ar=industries[t+lo:t+hi+1]-xe@beta
  assert ar.shape==(hi-lo+1,30) and np.isfinite(ar).all()
  rebuilt.append(dict(category=row.category,period=row.period,event_date=row.date,trade_date=calendar[t],window=w,car_bp=float(ar.sum(axis=0).mean()*10000),series_n=30))
r=pd.DataFrame(rebuilt);r.to_csv(out/'rebuilt_events.csv',index=False)
keys=['category','period','event_date','trade_date','window','series_n']
check=ev.merge(r,on=keys,suffixes=('_frozen','_rebuilt'),validate='one_to_one')
assert len(check)==len(ev)==522
check['difference_bp']=check.car_bp_rebuilt-check.car_bp_frozen
check.to_csv(out/'rebuild_comparison.csv',index=False)
assert check.difference_bp.abs().max()<1e-6
sel=ev[(ev.category==category)&(ev.window==window)].copy()
pp=pol[pol.category==category]
assert set(zip(sel.event_date,sel.period))==set(zip(pp.date,pp.period))
assert not sel.duplicated('trade_date').any()
sel.to_csv(out/'selected_events.csv',index=False)
rows=[]
for period in labels:
 v=sel[sel.period==period].car_bp.to_numpy();n=len(v)
 q=paper[(paper.category==category)&(paper.window==window)&(paper.period==period)]
 mean=float(v.mean()) if n else np.nan
 sd=float(v.std(ddof=1)) if n>1 else np.nan;se=sd/np.sqrt(n) if n>1 else np.nan
 t=mean/se if n>1 and se else np.nan;p=2*stats.t.sf(abs(t),n-1) if n>1 else np.nan
 margin=stats.t.ppf(.975,n-1)*se if n>1 else np.nan
 z=q.iloc[0] if len(q) else None
 rows.append(dict(period=period,n=n,mean_bp=mean,sd_bp=sd,se_bp=se,t=t,p=p,ci_low=mean-margin,ci_high=mean+margin,paper_display=z.paper_display if z is not None else '无样本',paper_t=z.paper_t if z is not None else '',paper_kp_bold=bool(z.paper_kp_bold) if z is not None else False,paper_observations=z.paper_observations if z is not None else 0))
s=pd.DataFrame(rows);s.to_csv(out/'summary.csv',index=False)
# Audit overlap of five-day sets using actual exchange calendar.
sets=[]
for e in sel.itertuples():
 t=int(np.searchsorted(calendar,e.trade_date));lo,hi=map(int,re.findall(r'-?\d+',window));sets.append((e.event_date,set(calendar[t+lo:t+hi+1])))
overlaps=[{'event1':d1,'event2':d2,'shared_days':sorted(w1&w2)} for i,(d1,w1) in enumerate(sets) for d2,w2 in sets[i+1:] if w1&w2]
closewide=prices.pivot(index='date',columns='code',values='close').sort_index()
close_diff=float((closewide.pct_change(fill_method=None)-wide).abs().iloc[1:].max().max())
audit=dict(input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.glob('*')) if p.is_file()},market_hash_match=True,prices_rows=len(prices),series=31,trading_days=len(calendar),date_range=[str(calendar[0]),str(calendar[-1])],price_duplicates=0,missing=0,return_pct_div100_vs_r_max=float((prices.return_pct/100-prices.r).abs().max()),close_return_max_abs_difference=close_diff,policy_rows=len(pol),policy_category_date_duplicates=0,all_same_date_groups={k:int(v) for k,v in pol.groupby('date').size().items() if v>1},upstream_same_date_metadata=pol.loc[pol.same_date_rows>1,['date','category','same_date_rows']].to_dict('records'),selected_category=category,selected_window=window,selected_event_counts={x:int((sel.period==x).sum()) for x in labels},same_category_trade_date_collisions=0,nontrading_mappings=[dict(category=c,event_date=d,trade_date=t) for c,d,t in mappings if d!=t],estimate_valid_days_min=min(effective),estimate_valid_days_max=max(effective),rebuilt_rows=len(check),max_rebuild_error_bp=float(check.difference_bp.abs().max()),selected_overlaps=overlaps,online_quote_query='未执行：无可用证券行情工具；使用课程冻结数据',starter_zip='HTTP 403; teacher scripts unavailable; independently implemented OLS reproduction',student_personal_checks='尚待学生本人完成；以下为AI执行并记录的核验',author=a.author)
(out/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(s.to_string(index=False));print('MAX_REBUILD_ERROR_BP',audit['max_rebuild_error_bp']);print('OVERLAPS',json.dumps(overlaps,ensure_ascii=False))
if not a.narrative:raise SystemExit(0)
narr=json.loads(Path(a.narrative).read_text())
for k in ['summary','interpretation','limits','ai']:assert isinstance(narr[k],str) and narr[k]
esc=lambda x:html.escape(str(x))
fmt=lambda x:f'{x:.3f}' if isinstance(x,(int,float,np.number)) and np.isfinite(x) else '—'
trs=''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in [labels[z.period],z.n,fmt(z.mean_bp),fmt(z.sd_bp),f'[{fmt(z.ci_low)}, {fmt(z.ci_high)}]',fmt(z.t),fmt(z.p),z.paper_display,z.paper_t,'是' if z.paper_kp_bold else '否',fmt(z.paper_observations)])+'</tr>' for z in s.itertuples())
finite=s[s.n>1];mn=min(-40,float(finite.ci_low.min())-15);mx=max(40,float(finite.ci_high.max())+15)
xpos=lambda v:220+(v-mn)/(mx-mn)*600
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 330" role="img" aria-labelledby="charttitle"><title id="charttitle">分期平均异常收益与95%事件层t置信区间，单位基点</title><rect width="900" height="330" fill="#fff"/>']
for tick in range(int(np.ceil(mn/25)*25),int(mx)+1,25):
 x=xpos(tick);svg.append(f'<path d="M{x} 45 V265" stroke="#e3e9ed"/><text x="{x}" y="290" text-anchor="middle" font-size="14">{tick}</text>')
svg.append(f'<path d="M{xpos(0)} 45 V265" stroke="#64748b" stroke-dasharray="5 4"/>')
for i,z in enumerate(s.itertuples()):
 y=85+i*75;svg.append(f'<text x="12" y="{y+5}" font-size="16">{esc(labels[z.period])} (n={z.n})</text>')
 if z.n>1:
  l,h,c=xpos(z.ci_low),xpos(z.ci_high),xpos(z.mean_bp)
  svg.append(f'<path d="M{l} {y} H{h} M{l} {y-7} V{y+7} M{h} {y-7} V{y+7}" stroke="#087e8b" stroke-width="3"/><circle cx="{c}" cy="{y}" r="6" fill="#087e8b"/><text x="{c}" y="{y-14}" text-anchor="middle" font-size="14">{z.mean_bp:.2f}</text>')
svg.append('<text x="520" y="320" text-anchor="middle" font-size="15">CAR均值（基点；100 bp = 1个百分点）</text></svg>');svg=''.join(svg)
(out/'figure.svg').write_text(svg)
manual_period=next(p for p in ['during','pre','post'] if (sel.period==p).any());vv=sel[sel.period==manual_period].sort_values('event_date');vals=vv.car_bp.tolist()
manual=' + '.join(f'({v:.6f})' if v<0 else f'{v:.6f}' for v in vals)
manual_mean=sum(round(v,6) for v in vals)/len(vals)
manualtext=f'以{labels[manual_period]}为例：均值 = ({manual}) ÷ {len(vals)} = {manual_mean:.6f} bp。使用未舍入CSV的程序均值为{np.mean(vals):.9f} bp；仅因展示舍入产生的差为{abs(manual_mean-np.mean(vals)):.9f} bp。此处是AI列出的可手工验算记录，尚未替代学生本人按计算器核验。'
checks=''.join(f'<li>{esc(v.event_date)}：market_events.csv 的 car_bp = {v.car_bp:.9f} bp；独立行情重建 = {float(r[(r.category==category)&(r.window==window)&(r.event_date==v.event_date)].car_bp.iloc[0]):.9f} bp。</li>' for v in sel.sort_values('event_date').iloc[[0,len(sel)//2,-1]].itertuples())
eventtable=sel.sort_values(['period','event_date']).to_html(index=False,float_format=lambda x:f'{x:.6f}',border=0)
selectedmap=[m for m in mappings if m[0]==category and m[1]!=m[2]]
maptext='；'.join(f'{d} → {t}' for c,d,t in selectedmap) or '无非交易日映射'
periodcounts='、'.join(f'{labels[z.period]}{z.n}个' for z in s.itertuples())
report=f'''<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1｜流动性政策与五日累计异常收益</title><style>
:root{{color-scheme:light}}*{{box-sizing:border-box}}body{{margin:0;background:#edf2f5;color:#172b3a;font:16px/1.8 system-ui,"Microsoft YaHei",sans-serif}}main{{max-width:1120px;margin:32px auto;background:white;padding:42px 48px;border-radius:16px}}h1{{font-size:30px;line-height:1.4}}h2{{margin-top:34px;font-size:22px;border-bottom:2px solid #dce9ed;padding-bottom:8px}}.eyebrow{{color:#087e8b;letter-spacing:2px}}.meta,figcaption,.note{{font-size:14px;color:#526573}}.summary{{background:#edf8f8;padding:20px;border-left:4px solid #087e8b}}table{{border-collapse:collapse;width:100%;font-size:13px;white-space:nowrap}}td,th{{padding:9px 11px;border-bottom:1px solid #dbe5ea;text-align:right}}th{{background:#edf4f7}}td:first-child,th:first-child{{text-align:left}}.scroll{{overflow-x:auto}}svg{{width:100%;height:auto}}details{{margin:18px 0;padding:14px;background:#f5f8fa}}summary{{cursor:pointer;font-weight:bold}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}}a{{color:#087e8b}}@media(max-width:700px){{main{{margin:0;padding:20px}}h1{{font-size:25px}}}}@media print{{body{{background:white}}main{{padding:0;margin:0;max-width:none}}details{{break-inside:avoid}}}}
</style></head><body><main><div class="eyebrow">M1 · 事件研究 · 课程冻结数据复算</div><h1>流动性政策公告附近的五日累计异常收益</h1><p class="meta">作者：{esc(a.author)}｜生成日期：2026-10-21（北京时间）｜版本：V1｜离线报告；未在线重新获取iFinD行情</p><p class="summary">{esc(narr['summary'])}</p>
<h2>1. 研究问题与变量</h2><p>在论文划分的疫情前、疫情期间和后续时期，流动性政策公告附近的股票市场五日累计异常收益如何变化？X为论文事件表中的 <code>{category}</code> 事件及其时期。Y为 <strong>{'CAR[-1,3]' if a.y=='car5' else 'AR(0)'}</strong>，单位为基点。CAR是实际收益减去市场模型正常收益后，在指定交易日窗口内相加的累计异常收益；不是实际指数涨幅。</p><p>先对每次事件的30个中信一级行业指数CAR等权平均，再对同一时期的事件等权平均（CAAR）。这不是上证指数自身的收益，也不是上市公司等权组合。</p>
<h2>2. 数据、分期与样本筛选</h2><p>使用上传的课程冻结文件：policy_events.csv（87项政策记录）、prices_daily.csv（31个序列、27,807行、897个共同交易日，2017-09-01至2021-05-14）、market_events.csv（522个事件—窗口组合）和paper_table3_full.csv（仅作原文对照）。先筛选政策类别，再选窗口；保留{periodcounts}，合计{len(sel)}个独立政策事件。30个行业不是30次政策事件。</p><ul><li>疫情前：2019-01-01至2019-12-30。</li><li>论文定义的疫情期间：2019-12-31至2020-04-28。</li><li>后续时期：2020-04-29至2021-04-30；此名称不表示疫情已经结束。</li></ul><p>当前87行事件表的日期唯一，政策类别—日期也无重复，因此本次没有额外删行。一般同日不同政策类型不能盲目合并；本文件未保留可供逐条核查的同日多行。该类别映射至同一交易日的事件也无碰撞。非交易日向后映射：{esc(maptext)}。时期按原始事件日期保留。公告与实施记录均沿用论文，不合并同一政策的不同实施日期。</p><p>例如2019-01-15、2020-04-15、2020-05-15的same_date_rows均为2，但当前表中各只出现一次，且均归为流动性事件。该字段说明上游同日记录数，不能据此把当前事件数翻倍，也不能仅凭此字段推断未提供记录的类别；本次沿用冻结分类。2020-12-15记录的描述却提到2021-01-15，存在日期文字不一致；本次保留结构化日期与冻结映射，不擅自更正，须回到原始公告核对。</p>
<p>市场模型为 rᵢₜ = αᵢ + βᵢrₘₜ + εᵢₜ，含截距，上证指数000001.SH为市场因子。以映射交易日为0，估计窗[-250,-20]含231个有效交易日；本次全部87事件均满足231日。return_pct除100一次得到小数收益，r仅交叉核验。事件窗{'[-1,3]含前1日至后3日，共5个交易日' if a.y=='car5' else '[0,0]仅事件日'}。缺失不填零、不插值；脚本遇到不完整估计窗或事件窗会停止。本次无缺失或因此删除的事件。证券—日期无重复；return_pct/100与r最大差约1.0×10⁻¹⁶，close计算的相邻日简单收益与输入收益最大差约3.6×10⁻¹⁵（首日因无前收盘价不作此项核验）。</p><p>独立OLS实现重新计算全部87×6=522行，和冻结中间表逐行匹配；最大绝对差 {audit['max_rebuild_error_bp']:.3g} bp。car_bp已为基点，读取后未再次乘10,000。起始包链接HTTP 403，未能获取教师脚本；本次代码为独立实现，不冒称运行过教师脚本。</p>
<h2>3. 分期结果与原文对照</h2><p><strong>表1｜{esc(category)}，{esc(window)}窗口，30行业等权组合的事件均值与不确定性（收益和区间单位：bp）</strong></p><div class="scroll"><table><thead><tr><th>时期</th><th>事件数</th><th>本次均值</th><th>事件SD</th><th>95% t区间</th><th>事件t值</th><th>双侧p</th><th>原文CAAR</th><th>原文BMP t</th><th>原文KP后显著</th><th>原文观测数</th></tr></thead><tbody>{trs}</tbody></table></div><p class="note">来源：本次均值由market_events.csv汇总，已用prices_daily.csv和policy_events.csv独立重建核验；原文栏仅来自paper_table3_full.csv。SD为事件CAR样本标准差。原文观测数=30×事件数，不能当作本次t检验样本量。原文星号照录（*、**、***通常对应10%、5%、1%水平）；本次不沿用原文星号。KP列记录转录表的加粗标记，不表示本次重新计算KP。</p><figure>{svg}<figcaption>图1｜圆点为时期事件均值，横线为双侧95% Student-t置信区间；虚线为零。区间反映事件层抽样不确定性，以独立事件为前提。样本：{periodcounts}；来源同表1。区间穿过零不等于证明没有反应；图中区间不能直接用于宣称跨期差异显著。</figcaption></figure><p>{esc(narr['interpretation'])}</p>
<h2>4. 验算与可追溯记录</h2><p>{esc(manualtext)}</p><p>三处CSV关键数字核对（由AI执行，未冒充学生本人操作）：</p><ul>{checks}</ul><p>学生提交前应亲自打开CSV核对上述三处，用计算器重算该期均值，并补填姓名与实际核验记录。现在的报告如实保留“尚待本人核验”状态。</p>
<h2>5. 解释边界与结论</h2><p>{esc(narr['limits'])}</p><p>本样本有{len(overlaps)}对同类别事件窗口存在交易日交集，详见附录；另有跨政策类别的同期消息，尚未完整排除。课堂t检验与置信区间没有校正事件依赖。原文BMP对事件诱发波动等作标准化处理，KP进一步考虑横截面相关；本次的事件层t检验无法精确复制二者。</p>
<h2>6. 来源与AI使用记录</h2><p>Shan, Y., Chen, Y., &amp; Xiao, Y. (2023). Monetary policy as market stabilizer in the COVID-19 pandemic. <em>Finance Research Letters, 55</em>, 103960. DOI: <a href="https://doi.org/10.1016/j.frl.2023.103960">10.1016/j.frl.2023.103960</a>。论文全文：<a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC10151028/">PMC10151028</a>。本次原文对照依据上传的表3转录，未声称已对照PDF逐字核验。</p><p>数据来源为课程既有iFinD行情冻结文件及论文政策表整理，见随包provenance.md与数据说明.md。manifest中的原始上游cars.csv未提供，无法验证其源文件哈希；本次仅验证可得market_events.csv的SHA-256完全匹配manifest。没有证券行情工具可用，未执行在线iFinD小批抽查，未编造查询时间或下载记录。参考目标报告A的结构，所有本次统计数值由脚本重新计算。</p><p>{esc(narr['ai'])}</p>
<details><summary>附录A｜公式与全部事件输入</summary><p>ARᵢₜ = rᵢₜ − (α̂ᵢ + β̂ᵢrₘₜ)；CARₑ = 10,000 × (1/30)ΣᵢΣₜ ARᵢₜ。时期均值 = Σₑ CARₑ / n；s² = Σₑ(CARₑ−均值)²/(n−1)；SE=s/√n；t=均值/SE，自由度n−1；95%区间=均值±t₀.₉₇₅,ₙ₋₁SE。若直接读取car_bp，不再乘10,000。</p><div class="scroll">{eventtable}</div></details><details><summary>附录B｜完整审计与窗口交叠记录</summary><pre>{esc(json.dumps(audit,ensure_ascii=False,indent=2))}</pre></details><p class="meta">交付检查：本HTML的CSS与SVG均内嵌，无脚本、无外部图像或字体依赖；引用链接只用于查阅来源，不影响离线阅读。技能和计算脚本随skill.zip提供。课程上传与V1关联需由提交入口完成，本报告未宣称已上传。</p></main></body></html>'''
(out/'report.html').write_text(report,encoding='utf-8')
print('HTML',out/'report.html')
