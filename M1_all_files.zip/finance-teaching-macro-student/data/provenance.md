# 数据与论文依据

Shan, Y., Chen, Y., & Xiao, Y. (2023). Monetary policy as market stabilizer in the COVID-19 pandemic. *Finance Research Letters, 55*, 103960. https://doi.org/10.1016/j.frl.2023.103960
全文：https://pmc.ncbi.nlm.nih.gov/articles/PMC10151028/ 。使用表3与政策事件表；不是作者代码包。

market_events.csv由课程已审计的iFinD行情市场模型CAR生成，先对30个中信一级行业指数CAR等权平均。它是总体组合，不是上证指数原始回报，不是公司等权组合。本包不展开行业差异。本次重新汇总真实中间数据，并非重新从MCP下载历史行情；宏观EDB MCP不能替代证券行情服务。

car_bp已经为基点，100bp=1个百分点；series_n必须为30。事件/窗口/类型唯一。同一天可对应不同政策类型，不能跨类型盲目去重。event_date为论文事件记录，可能包含宣布或实施日期；trade_date为既有处理映射交易日。精确公告时刻尚未全部复核，不擅称纯意外冲击。

估计窗[-250,-20]；上证指数为市场因子。窗口只允许输入数据中存在的六种窗口。pre=2019-01-01至2019-12-30；during=2019-12-31至2020-04-28；post=2020-04-29至2021-04-30，不表示疫情已结束。

论文值单位bp，保留原文报告精度。本包事件层Student-t检验不是原文BMP/KP的精确复制。事件少或重叠时推断较弱，不宣称因果效应；未检验跨期差异，不能以一组显著另一组不显著证明差异。
